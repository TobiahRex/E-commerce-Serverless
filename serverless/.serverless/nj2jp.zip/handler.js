(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _stringify = __webpack_require__(1);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _extends2 = __webpack_require__(2);

	var _extends3 = _interopRequireDefault(_extends2);

	var _runGraphQL = __webpack_require__(3);

	var _runGraphQL2 = _interopRequireDefault(_runGraphQL);

	var _connection = __webpack_require__(9);

	var _request = __webpack_require__(20);

	var _request2 = _interopRequireDefault(_request);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable global-require, import/first, no-unused-expressions, no-console */
	if (!global._babelPolyfill) __webpack_require__(21);

	module.exports.graphql = function (event, context, cb) {
	  console.log('\nEVENT: ', event);

	  (0, _connection.startDB)().then(function (dbResults) {
	    return (0, _runGraphQL2.default)((0, _extends3.default)({ event: event }, dbResults));
	  }).then(function (GraphQLResponse) {
	    console.log('\n//handler.js @ \nRESOLVE: ', GraphQLResponse);
	    context.succeed && context.succeed(GraphQLResponse);
	    cb(null, GraphQLResponse);
	  }).catch(function (error) {
	    console.log('\n//handler.js @ CATCH\nERROR: ', error);
	    context.error && context.error(error);
	  });
	};

	module.exports.wakeup = function (event, context, callback) {
	  console.log('Calling Wakeup Lambda.');
	  var options = {
	    "query": "query{FindProductById(_id: \"Test\") {_id, product { mainTitle title flavor price sku sizes nicotine_strengths routeTag vendor blurb images{ purpose url } dates {added_to_store  removed_from_store }}}}"
	  };

	  _request2.default.post(process.env.WAKE_UP_URL, { body: (0, _stringify2.default)(options) }, function (err, res) {
	    if (err) return console.error('waking up failed:', err);
	    console.log('woke up the sleeping lambda\nJSON response: \n', res);
	    return callback(null, res);
	  });
	};

/***/ }),
/* 1 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/helpers/extends");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _promise = __webpack_require__(4);

	var _promise2 = _interopRequireDefault(_promise);

	var _graphql = __webpack_require__(5);

	var _schema = __webpack_require__(6);

	var _schema2 = _interopRequireDefault(_schema);

	var _connection = __webpack_require__(9);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var runGraphQL = function runGraphQL(_ref) {
	  var event = _ref.event,
	      dbModels = _ref.dbModels,
	      db = _ref.db;
	  return new _promise2.default(function (resolve, reject) {
	    var _event$body = event.body,
	        variables = _event$body.variables,
	        query = _event$body.query;


	    (0, _graphql.graphql)(_schema2.default, query, null, dbModels, variables).then(function (dbResponse) {
	      console.log('\n//runGraphQL.js @ graphql.then: \ndbResponse = ', dbResponse);
	      return (0, _connection.closeDB)(db, dbResponse);
	    }).then(resolve).catch(function (error) {
	      console.log('\n//runGraphQL.js @ graphql.catch: \n error = ', error);
	      reject(error);
	    });
	  });
	}; /* eslint-disable no-console */
	exports.default = runGraphQL;

/***/ }),
/* 4 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

	module.exports = require("graphql");

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(5);

	var _productTypes = __webpack_require__(7);

	var _productTypes2 = _interopRequireDefault(_productTypes);

	var _userTypes = __webpack_require__(8);

	var _userTypes2 = _interopRequireDefault(_userTypes);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var query = new _graphql.GraphQLObjectType({
	  name: 'RootQueryType',
	  description: 'The primary query object.',
	  fields: function fields() {
	    return {
	      FetchUserProfile: _userTypes2.default.queries.FetchUserProfile,
	      FindProductById: _productTypes2.default.queries.FindProductById,
	      FindProductsByFlavor: _productTypes2.default.queries.FindProductsByFlavor,
	      PopularProducts: _productTypes2.default.queries.PopularProducts,
	      FetchMultipleProducts: _productTypes2.default.queries.FetchMultipleProducts
	    };
	  }
	});

	var mutation = new _graphql.GraphQLObjectType({
	  name: 'RootMutationType',
	  description: 'The primary mutation object.',
	  fields: function fields() {
	    return {
	      CreateProduct: _productTypes2.default.mutations.CreateProduct,
	      LoginOrRegister: _userTypes2.default.mutations.LoginOrRegister,
	      AddToMemberCart: _userTypes2.default.mutations.AddToMemberCart,
	      EditToMemberCart: _userTypes2.default.mutations.EditToMemberCart,
	      DeleteFromMemberCart: _userTypes2.default.mutations.DeleteFromMemberCart,
	      FindProductAndUpdate: _productTypes2.default.mutations.FindProductAndUpdate,
	      FindProductByIdAndDelete: _productTypes2.default.mutations.FindProductByIdAndDelete
	    };
	  }
	});

	exports.default = new _graphql.GraphQLSchema({
	  query: query,
	  mutation: mutation
	});

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(5);

	var rootType = new _graphql.GraphQLObjectType({
	  name: 'Product',
	  description: 'A store product.',
	  fields: {
	    _id: {
	      description: 'The ID of the Product.',
	      type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	    },
	    product: {
	      description: 'Object: All the important details for the product.',
	      type: new _graphql.GraphQLObjectType({
	        name: 'ProductObject',
	        fields: function fields() {
	          return {
	            mainTitle: {
	              description: 'The title for the Single Product page - e.g. You may not want it to be the name of the product but a "Category" of products.',
	              type: _graphql.GraphQLString
	            },
	            title: {
	              description: 'The title of the product.',
	              type: _graphql.GraphQLString
	            },
	            flavor: {
	              description: 'The flavor of the product.',
	              type: _graphql.GraphQLString
	            },
	            price: {
	              description: 'The price of the product. - WARNING: Do not add $ signs, Do not add (.) decimals.',
	              type: _graphql.GraphQLString
	            },
	            sku: {
	              description: 'The unique code for the product.',
	              type: _graphql.GraphQLString
	            },
	            size: {
	              description: 'The available sizes for the product.',
	              type: new _graphql.GraphQLEnumType({
	                name: 'ProductAvailableSizes',
	                /* eslint-disable quote-props */
	                values: {
	                  'small': {
	                    value: 30,
	                    description: '30 milliter bottle.'
	                  },
	                  'medium': {
	                    value: 60,
	                    description: '60 milliliter bottle.'
	                  },
	                  'large': {
	                    value: 120,
	                    description: '120 milliliter bottle'
	                  }
	                }
	              })
	            },
	            nicotineStrength: {
	              description: 'The nicotine strength for the new product.',
	              type: new _graphql.GraphQLEnumType({
	                name: 'ProductNicotineStrengthsEnum',
	                values: {
	                  two: {
	                    value: 2,
	                    description: '2mg of Nicotine.'
	                  },
	                  four: {
	                    value: 4,
	                    description: '4mg of Nicotine.'
	                  },
	                  six: {
	                    value: 6,
	                    description: '6mg of Nicotine'
	                  },
	                  eight: {
	                    value: 8,
	                    description: '8mg of Nicotine.'
	                  },
	                  ten: {
	                    value: 10,
	                    description: '8mg of Nicotine.'
	                  },
	                  twelve: {
	                    value: 12,
	                    description: '8mg of Nicotine.'
	                  },
	                  fourteen: {
	                    value: 14,
	                    description: '8mg of Nicotine.'
	                  },
	                  sixteen: {
	                    value: 16,
	                    description: '8mg of Nicotine.'
	                  },
	                  eighteen: {
	                    value: 18,
	                    description: '8mg of Nicotine.'
	                  }
	                }
	              })
	            },
	            images: {
	              description: 'Images array for the new Product.',
	              type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                name: 'ProductImageObject',
	                fields: function fields() {
	                  return {
	                    purpose: { type: _graphql.GraphQLString },
	                    url: { type: _graphql.GraphQLString }
	                  };
	                }
	              }))
	            },
	            routeTag: {
	              description: 'The name of the route for the product.',
	              type: _graphql.GraphQLString
	            },
	            vendor: {
	              description: 'The name of manufacturer of the new product.',
	              type: _graphql.GraphQLString
	            },
	            blurb: {
	              description: 'A description of the product.',
	              type: _graphql.GraphQLString
	            },
	            dates: {
	              description: 'Important clerical dates regarding the product.',
	              type: new _graphql.GraphQLObjectType({
	                name: 'ProductDateObject',
	                fields: function fields() {
	                  return {
	                    added_to_store: {
	                      description: 'The Date the product was first added to the store.',
	                      type: _graphql.GraphQLString
	                    },
	                    removed_from_store: {
	                      description: 'The Date the product was removed from the store.',
	                      type: _graphql.GraphQLString
	                    }
	                  };
	                }
	              })
	            },
	            quantities: {
	              description: 'Availability stats for this product.',
	              type: new _graphql.GraphQLObjectType({
	                name: 'ProductQuantityInfo',
	                fields: function fields() {
	                  return {
	                    available: {
	                      description: 'The available quanitty for this product.',
	                      type: _graphql.GraphQLInt
	                    },
	                    in_cart: {
	                      description: 'The quantity for products currently in customers\' carts.',
	                      type: _graphql.GraphQLInt
	                    }
	                  };
	                }
	              })
	            }
	          };
	        }
	      })
	    },
	    statistics: {
	      description: 'Statistics on purchases for this item.',
	      type: new _graphql.GraphQLObjectType({
	        name: 'ProductStatistics',
	        fields: function fields() {
	          return {
	            adds_to_cart: {
	              description: 'The amount of times someone has added this product to their cart.',
	              type: _graphql.GraphQLInt
	            },
	            completed_checkouts: {
	              description: 'The amount of times this item has been successfully purchased.',
	              type: _graphql.GraphQLInt
	            },
	            transactions: {
	              description: 'A list of transactions for this product.',
	              type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                name: 'ProductTransaction',
	                fields: function fields() {
	                  return {
	                    transaction_id: {
	                      description: 'The Mongo ID for transactions.',
	                      type: _graphql.GraphQLID
	                    },
	                    user_id: {
	                      description: 'The mongo ID for users.',
	                      type: _graphql.GraphQLID
	                    }
	                  };
	                }
	              }))
	            }
	          };
	        }
	      })
	    }
	  }
	});
	var queryTypes = {
	  popularProductsType: new _graphql.GraphQLObjectType({
	    name: 'PopularProductType',
	    description: 'The return fields for querying popular products.',
	    fields: function fields() {
	      return {
	        _id: {
	          description: 'The unique identification for this popular product.  Default value is a unique product category.',
	          type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	        },
	        docId: {
	          description: 'The Mongo ID for the underlying Product.',
	          type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	        },
	        title: {
	          description: 'The main Title for this Product.',
	          type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	        },
	        routeTag: {
	          description: 'The route tag (slug) for this product.',
	          type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	        },
	        images: {
	          description: 'The images for Popular Products.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	            name: 'PopularProductImages',
	            fields: function fields() {
	              return {
	                purpose: {
	                  description: 'The intended purpose for this image.',
	                  type: _graphql.GraphQLString
	                },
	                url: {
	                  description: 'The url for this image.',
	                  type: _graphql.GraphQLString
	                }
	              };
	            }
	          })))
	        },
	        completedCheckouts: {
	          description: 'The number of times this product has been successfully purchased.',
	          type: _graphql.GraphQLInt
	        }
	      };
	    }
	  })
	};

	var queries = {
	  FetchMultipleProducts: {
	    type: new _graphql.GraphQLList(rootType),
	    args: {
	      ids: {
	        description: 'An array of Product Mongo Ids.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(_graphql.GraphQLID))
	      }
	    },
	    resolve: function resolve(_, _ref, _ref2) {
	      var ids = _ref.ids;
	      var Product = _ref2.Product;
	      return Product.fetchMultiple(ids);
	    }
	  },
	  FindProductsByFlavor: {
	    type: new _graphql.GraphQLList(rootType),
	    args: {
	      flavor: {
	        description: 'The Mongo flavor of the products.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	      }
	    },
	    resolve: function resolve(_, _ref3, _ref4) {
	      var flavor = _ref3.flavor;
	      var Product = _ref4.Product;
	      return Product.findProductsByFlavor(flavor);
	    }
	  },
	  FindProductById: {
	    type: rootType,
	    args: {
	      _id: {
	        description: 'The Mongo _id of the product.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      }
	    },
	    resolve: function resolve(_, _ref5, _ref6) {
	      var _id = _ref5._id;
	      var Product = _ref6.Product;
	      return Product.findProductById(_id);
	    }
	  },
	  PopularProducts: {
	    type: new _graphql.GraphQLList(queryTypes.popularProductsType),
	    args: {
	      qty: {
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt),
	        description: 'The quantity of popular products to return.'
	      }
	    },
	    resolve: function resolve(_, _ref7, _ref8) {
	      var qty = _ref7.qty;
	      var Product = _ref8.Product;
	      return Product.getPopularProducts(qty);
	    }
	  }
	};
	var mutations = {
	  CreateProduct: { // This is only used from GraphiQL to seed database.
	    type: rootType,
	    description: 'Create new Product.',
	    args: {
	      product: {
	        description: 'Object: All the important details for the product.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'NewProductObject',
	          fields: function fields() {
	            return {
	              mainTitle: {
	                description: 'The main title for the Single Product page for the new product - e.g. The "Cateogry" of the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              title: {
	                description: 'The title of the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              flavor: {
	                description: 'The flavor of the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              price: {
	                description: 'The price of the new product. - WARNING: Do not add $ signs, Do not add (.) decimals.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              sku: {
	                description: 'The unique code for the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              size: {
	                description: 'The available sizes for the product.',
	                type: new _graphql.GraphQLNonNull(new _graphql.GraphQLEnumType({
	                  name: 'NewProductAvailableSizesInput',
	                  /* eslint-disable quote-props */
	                  values: {
	                    'small': {
	                      value: 30,
	                      description: '30 milliter bottle.'
	                    },
	                    'medium': {
	                      value: 60,
	                      description: '60 milliliter bottle.'
	                    },
	                    'large': {
	                      value: 120,
	                      description: '120 milliliter bottle'
	                    }
	                  }
	                }))
	              },
	              nicotineStrength: {
	                description: 'The nicotine strength for the new product.',
	                type: new _graphql.GraphQLNonNull(new _graphql.GraphQLEnumType({
	                  name: 'NewProductNicotineStrengthsEnum',
	                  values: {
	                    two: {
	                      value: 2,
	                      description: '2mg of Nicotine.'
	                    },
	                    four: {
	                      value: 4,
	                      description: '4mg of Nicotine.'
	                    },
	                    six: {
	                      value: 6,
	                      description: '6mg of Nicotine'
	                    },
	                    eight: {
	                      value: 8,
	                      description: '8mg of Nicotine.'
	                    },
	                    ten: {
	                      value: 10,
	                      description: '8mg of Nicotine.'
	                    },
	                    twelve: {
	                      value: 12,
	                      description: '8mg of Nicotine.'
	                    },
	                    fourteen: {
	                      value: 14,
	                      description: '8mg of Nicotine.'
	                    },
	                    sixteen: {
	                      value: 16,
	                      description: '8mg of Nicotine.'
	                    },
	                    eighteen: {
	                      value: 18,
	                      description: '8mg of Nicotine.'
	                    }
	                  }
	                }))
	              },
	              images: {
	                description: 'Images array for the new Product.',
	                type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	                  name: 'NewProductImageObject',
	                  fields: function fields() {
	                    return {
	                      purpose: {
	                        description: 'What this specific image will be used for - e.g. "Juice Card"',
	                        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	                      },
	                      url: {
	                        description: 'The S3 url for this image.',
	                        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	                      }
	                    };
	                  }
	                })))
	              },
	              routeTag: {
	                description: 'The name of the route for the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              vendor: {
	                description: 'The name of manufacturer of the new product.',
	                type: _graphql.GraphQLString
	              },
	              blurb: {
	                description: 'A description of the new product.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              quantities: {
	                description: 'Availability stats for this new product.',
	                type: new _graphql.GraphQLInputObjectType({
	                  name: 'NewProductQuantityInfo',
	                  fields: function fields() {
	                    return {
	                      available: {
	                        description: 'The available quanitty for this product.',
	                        type: _graphql.GraphQLInt
	                      },
	                      in_cart: {
	                        description: 'The quantity for products currently in customers\' carts.',
	                        type: _graphql.GraphQLInt
	                      }
	                    };
	                  }
	                })
	              }
	            };
	          }
	        }))
	      },
	      statistics: {
	        description: 'Statistics on purchases for this item.',
	        type: new _graphql.GraphQLInputObjectType({
	          name: 'NewProductStatisticsInput',
	          fields: function fields() {
	            return {
	              adds_to_cart: {
	                description: 'The amount of times someone has added this product to their cart.',
	                type: _graphql.GraphQLInt
	              },
	              completed_checkouts: {
	                description: 'The amount of times this item has been successfully purchased.',
	                type: _graphql.GraphQLInt
	              },
	              transactions: {
	                description: 'A list of transactions for this product.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	                  name: 'NewProductTransactionInput',
	                  fields: function fields() {
	                    return {
	                      transaction_id: {
	                        description: 'The Mongo ID for transactions.',
	                        type: _graphql.GraphQLID
	                      },
	                      user_id: {
	                        description: 'The mongo ID for users.',
	                        type: _graphql.GraphQLID
	                      }
	                    };
	                  }
	                }))
	              }
	            };
	          }
	        })
	      }
	    },
	    resolve: function resolve(_, _ref9, Product) {
	      var product = _ref9.product,
	          statistics = _ref9.statistics;
	      return Product.createProduct(product, statistics);
	    }
	  },
	  FindProductAndUpdate: {
	    type: rootType,
	    description: 'Find product by ID and update.',
	    args: {
	      _id: {
	        description: 'The mongo _id of the product to update.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      },
	      newProduct: {
	        description: 'Object: The updated product info.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UpdateProductObject',
	          fields: function fields() {
	            return {
	              mainTitle: {
	                description: 'The main title for the Single Product page for the new product - e.g. The "Cateogry" of the new product.',
	                type: _graphql.GraphQLString
	              },
	              title: {
	                description: 'The title of the new product.',
	                type: _graphql.GraphQLString
	              },
	              flavor: {
	                description: 'The flavor of the new product.',
	                type: _graphql.GraphQLString
	              },
	              price: {
	                description: 'The price of the new product. - WARNING: Do not add $ signs, Do not add (.) decimals.',
	                type: _graphql.GraphQLString
	              },
	              sku: {
	                description: 'The unique code for the new product.',
	                type: _graphql.GraphQLString
	              },
	              size: {
	                description: 'The available sizes for the product.',
	                type: new _graphql.GraphQLEnumType({
	                  name: 'ProductAvailableSizesInput',
	                  /* eslint-disable quote-props */
	                  values: {
	                    'small': {
	                      value: 30,
	                      description: '30 milliter bottle.'
	                    },
	                    'medium': {
	                      value: 60,
	                      description: '60 milliliter bottle.'
	                    },
	                    'large': {
	                      value: 120,
	                      description: '120 milliliter bottle'
	                    }
	                  }
	                })
	              },
	              nicotineStrength: {
	                description: 'The nicotine strength for the new product.',
	                type: new _graphql.GraphQLEnumType({
	                  name: 'UpdateProductNicotineStrengthsEnum',
	                  values: {
	                    two: {
	                      value: 2,
	                      description: '2mg of Nicotine.'
	                    },
	                    four: {
	                      value: 4,
	                      description: '4mg of Nicotine.'
	                    },
	                    six: {
	                      value: 6,
	                      description: '6mg of Nicotine'
	                    },
	                    eight: {
	                      value: 8,
	                      description: '8mg of Nicotine.'
	                    },
	                    ten: {
	                      value: 10,
	                      description: '8mg of Nicotine.'
	                    },
	                    twelve: {
	                      value: 12,
	                      description: '8mg of Nicotine.'
	                    },
	                    fourteen: {
	                      value: 14,
	                      description: '8mg of Nicotine.'
	                    },
	                    sixteen: {
	                      value: 16,
	                      description: '8mg of Nicotine.'
	                    },
	                    eighteen: {
	                      value: 18,
	                      description: '8mg of Nicotine.'
	                    }
	                  }
	                })
	              },
	              images: {
	                description: 'Images array for the new Product.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	                  name: 'UpdateProductImageObject',
	                  fields: function fields() {
	                    return {
	                      purpose: {
	                        description: 'What this specific image will be used for - e.g. "Juice Card"',
	                        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	                      },
	                      url: {
	                        description: 'The S3 url for this image.',
	                        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	                      }
	                    };
	                  }
	                }))
	              },
	              routeTag: {
	                description: 'The name of the route for the new product.',
	                type: _graphql.GraphQLString
	              },
	              vendor: {
	                description: 'The name of manufacturer of the new product.',
	                type: _graphql.GraphQLString
	              },
	              blurb: {
	                description: 'A description of the new product.',
	                type: _graphql.GraphQLString
	              },
	              quantities: {
	                description: 'Availability stats for this new product.',
	                type: new _graphql.GraphQLInputObjectType({
	                  name: 'UpdateProductQuantityInfo',
	                  fields: function fields() {
	                    return {
	                      available: {
	                        description: 'The available quanitty for this product.',
	                        type: _graphql.GraphQLInt
	                      },
	                      in_cart: {
	                        description: 'The quantity for products currently in customers\' carts.',
	                        type: _graphql.GraphQLInt
	                      }
	                    };
	                  }
	                })
	              }
	            };
	          }
	        }))
	      }
	    },
	    resolve: function resolve(_, _ref10, _ref11) {
	      var _id = _ref10._id,
	          newProduct = _ref10.newProduct;
	      var Product = _ref11.Product;
	      return Product.findProductAndUpdate(_id, newProduct);
	    }
	  },
	  FindProductByIdAndDelete: {
	    type: rootType,
	    description: 'Find product by ID and delete the product.',
	    args: {
	      _id: {
	        description: 'The Mongo _id of the product.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      }
	    },
	    resolve: function resolve(_, _ref12, _ref13) {
	      var _id = _ref12._id;
	      var Product = _ref13.Product;
	      return Product.findProductByIdAndDelete(_id);
	    }
	  }
	};

	exports.default = {
	  rootType: rootType,
	  queries: queries,
	  mutations: mutations
	};

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(5);

	var rootType = new _graphql.GraphQLObjectType({
	  name: 'RootUserType',
	  description: 'A User.',
	  fields: function fields() {
	    return {
	      _id: {
	        description: 'The ID of the User.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      },
	      name: {
	        description: 'The Given, Family, & Display name for the user.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserName',
	          fields: function fields() {
	            return {
	              first: {
	                description: 'The first name of the user.',
	                type: _graphql.GraphQLString
	              },
	              last: {
	                description: 'The last name of the user.',
	                type: _graphql.GraphQLString
	              },
	              display: {
	                description: 'The display name of the user.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })
	      },
	      pictures: {
	        description: 'Pictures of the user in different sizes.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserPicture',
	          fields: function fields() {
	            return {
	              small: {
	                description: 'Small user image used for the Navbar avatar.',
	                type: _graphql.GraphQLString
	              },
	              large: {
	                description: 'Large user image used for the user dashboard.',
	                type: _graphql.GraphQLString
	              },
	              default: {
	                description: 'The default user avatar if none is supplied.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })
	      },
	      authentication: {
	        description: 'Authentication information for user.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserAuthentication',
	          fields: function fields() {
	            return {
	              signedUp: {
	                description: 'The Date this user first signed up for newsletters.',
	                type: _graphql.GraphQLString
	              },
	              password: {
	                description: 'This user\'s password if using email signup.',
	                type: _graphql.GraphQLString
	              },
	              createdAt: {
	                description: 'The date this user was created.',
	                type: _graphql.GraphQLString
	              },
	              totalLogins: {
	                description: 'The number of times this user has logged in.',
	                type: _graphql.GraphQLInt
	              },
	              logins: {
	                description: 'The last time this user logged in.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserLastLogin',
	                  fields: function fields() {
	                    return {
	                      date: {
	                        description: 'The Date the user last logged in.',
	                        type: _graphql.GraphQLString
	                      },
	                      device: {
	                        description: 'The type of device the user logged in with.',
	                        type: _graphql.GraphQLString
	                      }
	                    };
	                  }
	                }))
	              },
	              ageVerified: {
	                description: 'Verification if the user is at least 20 years of age.',
	                type: _graphql.GraphQLBoolean
	              },
	              auth0Identities: {
	                description: 'An array of identity object from Auth0 for each different type of login used by the user.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserAuth0Identities',
	                  fields: function fields() {
	                    return {
	                      provider: {
	                        description: 'The Social-Login Provider.',
	                        type: _graphql.GraphQLString
	                      },
	                      user_id: {
	                        description: 'The Auth0 User ID for this login type.',
	                        type: _graphql.GraphQLString
	                      },
	                      connection: {
	                        description: 'The type of Auth0 connection that was used.',
	                        type: _graphql.GraphQLString
	                      },
	                      isSocial: {
	                        description: 'Verifies that a Social Login type was used.',
	                        type: _graphql.GraphQLBoolean
	                      }
	                    };
	                  }
	                }))
	              }
	            };
	          }
	        })
	      },
	      contactInfo: {
	        description: 'Contact info & GeoLocation info for user.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserContanctInfo',
	          fields: function fields() {
	            return {
	              email: {
	                description: 'The email for this user.',
	                type: _graphql.GraphQLString
	              },
	              phone: {
	                description: 'The phone number for this user.',
	                type: _graphql.GraphQLString
	              },
	              locale: {
	                description: 'The users language of choice as determined by the Social Login provider or their preference.',
	                type: _graphql.GraphQLString
	              },
	              timezone: {
	                description: 'The users local Time Zone - Retrieved from Social Login Provider.',
	                type: _graphql.GraphQLInt
	              },
	              location: {
	                description: 'IP address, lat, long, & country code. for this user from their last login.',
	                type: new _graphql.GraphQLObjectType({
	                  name: 'UserGeolocation',
	                  fields: function fields() {
	                    return {
	                      ipAddress: {
	                        description: 'IP address this user last used.',
	                        type: _graphql.GraphQLString
	                      },
	                      lat: {
	                        description: 'Latitude coord. this user last logged in from.',
	                        type: _graphql.GraphQLString
	                      },
	                      long: {
	                        description: 'Longitude coord. this user last logged in from.',
	                        type: _graphql.GraphQLString
	                      },
	                      country: {
	                        description: 'Country code this user last logged in from.',
	                        type: _graphql.GraphQLString
	                      }
	                    };
	                  }
	                })
	              },
	              devices: {
	                description: 'The mobile devices used by a user to connect to Social Apps - From Social Login Providers Meta Data.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserDevices',
	                  fields: function fields() {
	                    return {
	                      hardware: {
	                        description: 'The mobile Phone type.',
	                        type: _graphql.GraphQLString
	                      },
	                      os: {
	                        description: 'The operating system for the mobile device.',
	                        type: _graphql.GraphQLString
	                      }
	                    };
	                  }
	                }))
	              },
	              socialNetworks: {
	                description: 'An array of Social Networks used by the user + their respective account links.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserSocialNetwork',
	                  fields: function fields() {
	                    return {
	                      name: {
	                        description: 'The name of the Social Network.',
	                        type: _graphql.GraphQLString
	                      },
	                      link: {
	                        description: 'The Social Network Link for this users account.',
	                        type: _graphql.GraphQLString
	                      }
	                    };
	                  }
	                }))
	              }
	            };
	          }
	        })
	      },
	      shopping: {
	        description: 'The Users Shopping Details: What\'s currently in the Users cart. What transactions have they made.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserShopping',
	          fields: function fields() {
	            return {
	              cart: {
	                description: 'The Users shopping cart.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserCart',
	                  fields: function fields() {
	                    return {
	                      qty: {
	                        description: 'The quantity of items of this product.',
	                        type: _graphql.GraphQLInt
	                      },
	                      nicotineStrength: {
	                        description: 'The nicotine strength of this product.',
	                        type: _graphql.GraphQLInt
	                      },
	                      product: {
	                        description: 'The Mongo ObjectID for this product.',
	                        type: _graphql.GraphQLID
	                      }
	                    };
	                  }
	                }))
	              },
	              transactions: {
	                description: 'The date this user first signed up for newsletters - Typically coincides with users first purchase.',
	                type: new _graphql.GraphQLList(_graphql.GraphQLString)
	              }
	            };
	          }
	        })
	      },
	      permissions: {
	        description: 'Authorization permissions granted for user.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserPermissions',
	          fields: function fields() {
	            return {
	              role: {
	                description: 'The authorization role for this user.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })
	      },
	      userStory: {
	        description: 'Bio information for new user.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserInputStory',
	          fields: function fields() {
	            return {
	              age: {
	                description: 'The age of this new user.',
	                type: _graphql.GraphQLInt
	              },
	              birthday: {
	                description: 'The birthday of this new user.',
	                type: _graphql.GraphQLString
	              },
	              bio: {
	                description: 'The biography of this new user.',
	                type: _graphql.GraphQLString
	              },
	              gender: {
	                description: 'The User\'s gender.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })
	      },
	      marketHero: {
	        description: 'The User\'s Market Hero Meta-Data.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserMarketHero',
	          fields: function fields() {
	            return {
	              tags: {
	                description: 'Array of objects, containing all the "Tags" that have been added to this User\'s Market Hero profile, and the respective date.',
	                type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	                  name: 'UserMarketHeroTags',
	                  fields: function fields() {
	                    return {
	                      name: {
	                        description: 'The name of the "Tag".',
	                        type: _graphql.GraphQLString
	                      },
	                      date: {
	                        description: 'The Date this "Tag" was added the User\'s Market Hero profile.',
	                        type: _graphql.GraphQLString
	                      }
	                    };
	                  }
	                }))
	              }
	            };
	          }
	        })
	      },
	      socialProfileBlob: {
	        description: 'The social network profile information for this user.  Captured at Registration.',
	        type: new _graphql.GraphQLObjectType({
	          name: 'UserSocialProfileBlob',
	          fields: function fields() {
	            return {
	              line: {
	                description: 'The Social Profile for the User\'s LINE account.',
	                type: _graphql.GraphQLString
	              },
	              facebook: {
	                description: 'The Social Profile for the User\'s Facebook account.',
	                type: _graphql.GraphQLString
	              },
	              google: {
	                description: 'The Social Profile for the User\'s Google account.',
	                type: _graphql.GraphQLString
	              },
	              twitter: {
	                description: 'The Social Profile for the User\'s Twitter account.',
	                type: _graphql.GraphQLString
	              },
	              linkedin: {
	                description: 'The Social Profile for the User\'s Linkedin account.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })
	      }
	    };
	  }
	});
	var queries = {
	  FetchUserProfile: {
	    type: rootType,
	    args: {
	      id: {
	        description: 'The Users Mongo ID. ',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      }
	    },
	    resolve: function resolve(_, _ref, _ref2) {
	      var id = _ref.id;
	      var User = _ref2.User;
	      return User.fetchUserProfile(id);
	    }
	  }
	};
	var mutations = {
	  LoginOrRegister: {
	    type: rootType,
	    description: 'Create new User.',
	    args: {
	      auth0Id: {
	        description: 'The Auth0 User ID to cross check with all Mongo User ID\'s to Login and if no match is found, create a new User.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	      },
	      loginType: {
	        description: 'The Social Network used to login or register.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	      },
	      name: {
	        description: 'The Given, Family, & Display name for the new user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserNameInput',
	          fields: function fields() {
	            return {
	              first: {
	                description: 'The first name of the new user.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              last: {
	                description: 'The last name of the new user.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              display: {
	                description: 'The display name of the new user.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              }
	            };
	          }
	        }))
	      },
	      pictures: {
	        description: 'Pictures of the user in different sizes.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserPictureInput',
	          fields: function fields() {
	            return {
	              small: {
	                description: 'Small user image used for the Navbar avatar.',
	                type: _graphql.GraphQLString
	              },
	              large: {
	                description: 'Large user image used for the user dashboard.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        }))
	      },
	      authentication: {
	        description: 'Authentication information for user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserAuthenticationInput',
	          fields: function fields() {
	            return {
	              signedUp: {
	                description: 'The Date this new user first signed up for newsletters.',
	                type: _graphql.GraphQLString
	              },
	              password: {
	                description: 'This new user\'s password if using email signup.',
	                type: _graphql.GraphQLString
	              },
	              createdAt: {
	                description: 'The date this new user was created.',
	                type: _graphql.GraphQLString
	              },
	              totalLogins: {
	                description: 'The number of times this new user has logged in.',
	                type: _graphql.GraphQLInt
	              },
	              ageVerified: {
	                description: 'Verification if the user is at least 20 years of age.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLBoolean)
	              }
	            };
	          }
	        }))
	      },
	      authenticationLogins: {
	        description: 'The last time this new user logged in.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'UserLastLoginInput',
	          fields: function fields() {
	            return {
	              date: {
	                description: 'The Date the user last logged in.',
	                type: _graphql.GraphQLString
	              },
	              device: {
	                description: 'The type of device the user logged in with.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })))
	      },
	      authenticationAuth0Identities: {
	        description: 'An array of identity object from Auth0 for each different type of login used by the user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'UserAuth0IdentitiesInput',
	          fields: function fields() {
	            return {
	              provider: {
	                description: 'The Social-Login Provider.',
	                type: _graphql.GraphQLString
	              },
	              user_id: {
	                description: 'The Auth0 User ID for this login type.',
	                type: _graphql.GraphQLString
	              },
	              connection: {
	                description: 'The type of Auth0 connection that was used.',
	                type: _graphql.GraphQLString
	              },
	              isSocial: {
	                description: 'Verifies that a Social Login type was used.',
	                type: _graphql.GraphQLBoolean
	              }
	            };
	          }
	        })))
	      },
	      contactInfo: {
	        description: 'Contact info & GeoLocation info for user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserContactInfoInput',
	          fields: function fields() {
	            return {
	              email: {
	                description: 'The email for this user.',
	                type: _graphql.GraphQLString
	              },
	              phone: {
	                description: 'The phone number for this user.',
	                type: _graphql.GraphQLString
	              },
	              locale: {
	                description: 'The users language of choice as determined by the Social Login provider or their preference.',
	                type: _graphql.GraphQLString
	              },
	              timezone: {
	                description: 'The users local Time Zone - Retrieved from Social Login Providers.',
	                type: _graphql.GraphQLInt
	              }
	            };
	          }
	        }))
	      },
	      contactInfoLocation: {
	        description: 'IP address, lat, long, & country code. for this user from their last login.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserLocationInput',
	          fields: function fields() {
	            return {
	              ipAddress: {
	                description: 'IP address this user last used.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              lat: {
	                description: 'Latitude coord. this user last logged in from.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              long: {
	                description: 'Longitude coord. this user last logged in from.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              },
	              country: {
	                description: 'Country code this user last logged in from.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              }
	            };
	          }
	        }))
	      },
	      contactInfoDevices: {
	        description: 'The mobile devices used by a user to connect to Social Apps - From Social Login Providers Meta Data.',
	        type: new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'UserDevicesInput',
	          fields: function fields() {
	            return {
	              hardware: {
	                description: 'The mobile Phone type.',
	                type: _graphql.GraphQLString
	              },
	              os: {
	                description: 'The operating system for the mobile device.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        }))
	      },
	      contactInfoSocialNetworks: {
	        description: 'An array of Social Networks used by the user + their respective account links.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'UserSocialNetworkInput',
	          fields: function fields() {
	            return {
	              name: {
	                description: 'The name of the Social Network.',
	                type: _graphql.GraphQLString
	              },
	              link: {
	                description: 'The Social Network Link for this users account.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        })))
	      },
	      shopping: {
	        description: 'The Users Shopping Details: What\'s currently in the Users cart. What transactions have they made.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserShoppingInput',
	          fields: function fields() {
	            return {
	              transactions: {
	                description: 'The date this user first signed up for newsletters - Typically coincides with users first purchase.',
	                type: new _graphql.GraphQLList(_graphql.GraphQLString)
	              }
	            };
	          }
	        }))
	      },
	      shoppingCart: {
	        description: 'The Users shopping cart.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'UserCartInput',
	          fields: function fields() {
	            return {
	              qty: {
	                description: 'The quantity of items of this product.',
	                type: _graphql.GraphQLInt
	              },
	              nicotineStrength: {
	                description: 'The nicotine strength of this product.',
	                type: _graphql.GraphQLInt
	              },
	              product: {
	                description: 'The Mongo ObjectID for this product.',
	                type: _graphql.GraphQLID
	              }
	            };
	          }
	        })))
	      },
	      permissions: {
	        description: 'Authorization permissions granted for user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserPermissionsInput',
	          fields: function fields() {
	            return {
	              role: {
	                description: 'The authorization role for this user.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	              }
	            };
	          }
	        }))
	      },
	      userStory: {
	        description: 'Bio information for new user.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserStoryInput',
	          fields: function fields() {
	            return {
	              age: {
	                description: 'The age of this new user.',
	                type: _graphql.GraphQLInt
	              },
	              birthday: {
	                description: 'The birthday of this new user.',
	                type: _graphql.GraphQLString
	              },
	              bio: {
	                description: 'The biography of this new user.',
	                type: _graphql.GraphQLString
	              },
	              gender: {
	                description: 'The User\'s gender.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        }))
	      },
	      socialProfileBlob: {
	        description: 'The users collection of social profiles from their Social Login accounts.',
	        type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	          name: 'UserSocialProfileBlobInput',
	          fields: function fields() {
	            return {
	              line: {
	                description: 'The Social Profile for the User\'s LINE account.',
	                type: _graphql.GraphQLString
	              },
	              facebook: {
	                description: 'The Social Profile for the User\'s Facebook account.',
	                type: _graphql.GraphQLString
	              },
	              google: {
	                description: 'The Social Profile for the User\'s Google account.',
	                type: _graphql.GraphQLString
	              },
	              twitter: {
	                description: 'The Social Profile for the User\'s Twitter account.',
	                type: _graphql.GraphQLString
	              },
	              linkedin: {
	                description: 'The Social Profile for the User\'s Linkedin account.',
	                type: _graphql.GraphQLString
	              }
	            };
	          }
	        }))
	      }
	    },
	    resolve: function resolve(_, args, _ref3) {
	      var User = _ref3.User;
	      return User.loginOrRegister(args);
	    }
	  },
	  AddToMemberCart: {
	    type: rootType,
	    description: 'Add products to the members cart.',
	    args: {
	      userId: {
	        description: 'The User\'s Mongo ObjectId.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      },
	      qty: {
	        description: 'The quantity of products to add.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt)
	      },
	      nicotineStrength: {
	        description: 'The nicotine strength of the product to add.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt)
	      },
	      product: {
	        description: 'The Mongo ObjectId of the product to add.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      }
	    },
	    resolve: function resolve(_, args, _ref4) {
	      var User = _ref4.User;
	      return User.addToMemberCart(args);
	    }
	  },
	  DeleteFromMemberCart: {
	    type: rootType,
	    description: 'Delete a Product from the Users cart.',
	    args: {
	      productId: {
	        description: 'The Product Mongo Id to delete.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      },
	      userId: {
	        description: 'The User Mongo Id to perform the operation on.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      }
	    },
	    resolve: function resolve(_, args, _ref5) {
	      var User = _ref5.User;
	      return User.deleteFromCart(args);
	    }
	  },
	  EditToMemberCart: {
	    type: rootType,
	    description: 'Update products in the members cart.',
	    args: {
	      userId: {
	        description: 'The User\'s Mongo ObjectId.',
	        type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	      },
	      products: {
	        description: 'A list of Products to be inserted into the users DB cart.',
	        type: new _graphql.GraphQLList(new _graphql.GraphQLInputObjectType({
	          name: 'ProductsInput',
	          fields: function fields() {
	            return {
	              qty: {
	                description: 'The quantity of products to update.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt)
	              },
	              nicotineStrength: {
	                description: 'The nicotine strength of the product to update.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt)
	              },
	              product: {
	                description: 'The Mongo ObjectId of the product to update.',
	                type: new _graphql.GraphQLNonNull(_graphql.GraphQLID)
	              }
	            };
	          }
	        }))
	      }
	    },
	    resolve: function resolve(_, args, _ref6) {
	      var User = _ref6.User;
	      return User.editToMemberCart(args);
	    }
	  }
	};
	var UserTypes = {
	  rootType: rootType,
	  queries: queries,
	  mutations: mutations
	};
	exports.default = UserTypes;

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.startDB = exports.closeDB = undefined;

	var _promise = __webpack_require__(4);

	var _promise2 = _interopRequireDefault(_promise);

	var _mongoose = __webpack_require__(10);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _product = __webpack_require__(11);

	var _product2 = _interopRequireDefault(_product);

	var _user = __webpack_require__(17);

	var _user2 = _interopRequireDefault(_user);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	_mongoose2.default.Promise = _promise2.default; /* eslint-disable no-console, no-constant-condition */

	var dotenv = __webpack_require__(19).config({ silent: true }); //eslint-disable-line
	var MONGO_DB = process.env.MONGO_URI;

	if (!MONGO_DB) throw new Error('MONGO_DB URI value is: ' + (MONGO_DB.length ? MONGO_DB : 'undefined'));

	var mongooseConnection = function mongooseConnection() {
	  return new _promise2.default(function (resolve) {
	    var newDB = _mongoose2.default.createConnection(MONGO_DB, console.log);
	    resolve(newDB);
	  });
	};

	var closeDB = exports.closeDB = function closeDB(db, GraphQLResponse) {
	  return new _promise2.default(function (resolve) {
	    db.close(function () {
	      console.log('\n//mongo/connection.js @ CLOSE DB');
	      console.log('\n//mongo/connection.js \ndb.connections AFTER close: ', db.base.connections);
	      resolve(GraphQLResponse);
	    });
	  });
	};

	var startDB = exports.startDB = function startDB() {
	  return new _promise2.default(function (resolve) {
	    mongooseConnection().then(function (newDB) {
	      console.log('\nMongo Connected @ ' + MONGO_DB);
	      console.log('\nNew DB = ', newDB);
	      resolve({
	        db: newDB,
	        dbModels: {
	          Product: (0, _product2.default)(newDB),
	          User: (0, _user2.default)(newDB)
	        }
	      });
	    }).catch(function (error) {
	      return console.log('\nCould not connect to Mongo DB.\nERROR: ' + error);
	    });
	  });
	};

/***/ }),
/* 10 */
/***/ (function(module, exports) {

	module.exports = require("mongoose");

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _defineProperty2 = __webpack_require__(12);

	var _defineProperty3 = _interopRequireDefault(_defineProperty2);

	var _keys = __webpack_require__(13);

	var _keys2 = _interopRequireDefault(_keys);

	var _stringify = __webpack_require__(1);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _toConsumableArray2 = __webpack_require__(14);

	var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

	var _promise = __webpack_require__(4);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(15);

	var _productSchema = __webpack_require__(16);

	var _productSchema2 = _interopRequireDefault(_productSchema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console */
	exports.default = function (db) {
	  _productSchema2.default.statics.findProductsByFlavor = function (flavor) {
	    return new _promise2.default(function (resolve, reject) {
	      Product.find({ 'product.flavor': flavor }).exec().then(function (dbProducts) {
	        console.log('\n        Found ' + dbProducts.length + ' popular product(s) with Flavor: "' + flavor + '"!\n      ');
	        resolve(dbProducts);
	      }).catch(function (error) {
	        reject({
	          problem: 'Could not find any products with flavor ' + flavor + '.\n\n        Mongo Error = ' + error
	        });
	      });
	    });
	  };

	  _productSchema2.default.statics.fetchMultiple = function (ids) {
	    return new _promise2.default(function (resolve, reject) {
	      if (!ids.length) {
	        resolve([]);
	      } else {
	        Product.find({ _id: { $in: [].concat((0, _toConsumableArray3.default)(ids)) } }).exec().then(function (dbProducts) {
	          console.log('Found multiple Products.: ', dbProducts);
	          resolve(dbProducts);
	        }).catch(function (error) {
	          return reject('\n        problem: Could not fetch multiple products.\n\n        Mongo Error = ' + error + '.\n      ');
	        });
	      }
	    });
	  };

	  _productSchema2.default.statics.findProductByIdAndDelete = function (_id) {
	    return new _promise2.default(function (resolve, reject) {
	      Product.findByIdAndRemove(_id).exec().then(resolve).catch(function (error) {
	        return reject({
	          problem: 'Could not create a delete product with _id:' + _id + '.  Verify the id is valid.\n      Mongoose Error = ' + error
	        });
	      });
	    });
	  };

	  _productSchema2.default.statics.createProduct = function (product, statistics) {
	    return new _promise2.default(function (resolve, reject) {
	      _bluebird.Promise.fromCallback(function (cb) {
	        return Product.create({ product: product, statistics: statistics }, cb);
	      }).then(function (newProduct) {
	        console.log('\n//mongo/model/product.js\n @ createProduct RESOLVE\n', newProduct);
	        resolve(newProduct);
	      }).catch(function (error) {
	        reject({
	          problem: 'Could not create a new product with this product object: ' + (0, _stringify2.default)({ product: product }, null, 2) + '\n        Mongoose Error = ' + error
	        });
	      });
	    });
	  };

	  _productSchema2.default.statics.findProductById = function (_id) {
	    return new _promise2.default(function (resolve, reject) {
	      Product.findById(_id).exec().then(function (dbProduct) {
	        console.log('\n//mongo/model/product.js\n @ findProductById RESOLVE\n', dbProduct);
	        resolve(dbProduct);
	      }).catch(function (error) {
	        reject({
	          problem: 'Could not find the product with id ' + _id + '.  Are you sure that product exists?\n        Mongo Error = ' + error
	        });
	      });
	    });
	  };

	  _productSchema2.default.statics.findProductAndUpdate = function (_id, productObj) {
	    return new _promise2.default(function (resolve, reject) {
	      var newProductObj = {};
	      (0, _keys2.default)(productObj).map(function (key) {
	        if (key === 'images') {
	          var imageKeys = [];
	          var imageObjs = [];
	          productObj.images.forEach(function (imageObj, i) {
	            imageKeys.push('product.images[' + i + ']');
	            imageObjs.push(imageObj);
	          });
	          return imageKeys.map(function (newKey, i) {
	            return (0, _defineProperty3.default)({}, newKey, imageObjs[i]);
	          });
	        }
	        var newKey = 'product.' + key;
	        var value = productObj[key];
	        return (0, _defineProperty3.default)({}, newKey, value);
	      }).forEach(function (object) {
	        var key = (0, _keys2.default)(object)[0];
	        newProductObj[key] = object[key];
	      });

	      console.log('\nnewProductObj: ', newProductObj);

	      Product.findByIdAndUpdate(_id, { $set: newProductObj }, { new: true }).exec().then(function (updatedProduct) {
	        console.log('\n        Updated Product!: ' + _id + ';\n        ');
	        resolve(updatedProduct);
	      }).catch(function (error) {
	        return reject({
	          problem: 'Could not find the product with id ' + _id + '. Are you sure that product exists?\n      Mongo Error = ' + error
	        });
	      });
	    });
	  };

	  _productSchema2.default.statics.getPopularProducts = function (qty) {
	    return new _promise2.default(function (resolve, reject) {
	      Product.aggregate([{ $group: {
	          _id: '$product.flavor',
	          docId: { $first: '$_id' },
	          title: { $first: '$product.title' },
	          routeTag: { $first: '$product.routeTag' },
	          images: { $first: '$product.images' },
	          completedCheckouts: { $first: '$statistics.completed_checkouts' }
	        } }, { $sort: { completedCheckouts: -1 } }, { $limit: qty }]).exec().then(function (dbProducts) {
	        console.log('\n        Found the following products: ' + (0, _stringify2.default)(dbProducts, null, 2) + '\n      ');
	        resolve(dbProducts);
	      }).catch(function (error) {
	        return reject({
	          problem: 'Could not fetch the ' + qty + ' products you requested.\n      Mongo Error = ' + error
	        });
	      });
	    });
	  };

	  var Product = db.model('Product', _productSchema2.default);
	  return Product;
	};

/***/ }),
/* 12 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/helpers/defineProperty");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/object/keys");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/helpers/toConsumableArray");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

	module.exports = require("bluebird");

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(10).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var productSchema = new Schema({
	  product: {
	    mainTitle: {
	      type: String,
	      required: true
	    },
	    title: {
	      type: String,
	      required: true
	    },
	    flavor: {
	      type: String,
	      required: true
	    },
	    price: {
	      type: String,
	      required: true,
	      default: 30
	    },
	    sku: {
	      type: String,
	      required: true
	    },
	    size: {
	      type: Number,
	      enum: [30, 60, 120],
	      required: true
	    },
	    nicotineStrength: {
	      type: Number,
	      enum: [2, 4, 6, 8, 10, 12, 14, 16, 18],
	      required: true
	    },
	    images: [{
	      purpose: {
	        type: String,
	        required: true
	      },
	      url: {
	        type: String,
	        required: true
	      }
	    }],
	    routeTag: {
	      type: String,
	      required: true
	    },
	    vendor: { type: String },
	    blurb: {
	      type: String,
	      required: true
	    },
	    dates: {
	      added_to_store: {
	        type: Date,
	        default: Date.now
	      },
	      removed_from_store: {
	        type: Date
	      }
	    },
	    quantities: {
	      available: { type: Number },
	      in_cart: { type: Number }
	    }
	  },
	  reviews: [{
	    reviews_id: { type: ObjectId, ref: 'Reviews' },
	    user_id: { type: ObjectId, ref: 'User' }
	  }],
	  distribution: {
	    restock_threshold: {
	      type: Number,
	      default: 500
	    },
	    restock_amount: {
	      type: Number,
	      default: 500
	    },
	    last_replenishment: [{
	      date: {
	        type: Date
	      },
	      amount: {
	        type: Number,
	        default: 500
	      }
	    }],
	    wholesale_price: { type: Number }
	  },
	  statistics: {
	    adds_to_cart: { type: Number },
	    completed_checkouts: { type: Number },
	    transactions: [{
	      transaction_id: { type: ObjectId, ref: 'Transaction' },
	      user_id: { type: ObjectId, ref: 'User' }
	    }]
	  }
	});
	exports.default = productSchema;

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _toConsumableArray2 = __webpack_require__(14);

	var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

	var _extends2 = __webpack_require__(2);

	var _extends3 = _interopRequireDefault(_extends2);

	var _promise = __webpack_require__(4);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(15);

	var _userSchema = __webpack_require__(18);

	var _userSchema2 = _interopRequireDefault(_userSchema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console */
	exports.default = function (db) {
	  _userSchema2.default.statics.fetchUserProfile = function (userId) {
	    return new _promise2.default(function (resolve, reject) {
	      User.findById(userId).exec().then(function (dbUser) {
	        console.log('\n        User Found: ' + dbUser._id + '\n        Sending updated profile to Client.\n      ');
	        resolve(dbUser);
	      }).catch(function (error) {
	        return reject('\n      Could Not find a user with this is: ' + userId + '\n\n      Mongo ERROR: ' + error + '\n      ');
	      });
	    });
	  };

	  _userSchema2.default.statics.loginOrRegister = function (args) {
	    return new _promise2.default(function (resolve, reject) {
	      var auth0Id = args.auth0Id;
	      var loginType = args.loginType;
	      delete args.auth0Id;
	      delete args.loginType;

	      User.findOne({ 'authentication.auth0Identities.user_id': auth0Id }).exec().then(function (dbUser) {
	        if (!dbUser) return User.registerUser(args);
	        return User.loginUser(loginType, dbUser, args);
	      }).then(resolve).catch(function (error) {
	        return reject({ problem: error });
	      });
	    });
	  };

	  _userSchema2.default.statics.loginUser = function (loginType, dbUser, userObj) {
	    return new _promise2.default(function (resolve) {
	      console.log('Found Existing User.\n');
	      dbUser.authentication.totalLogins += 1;
	      dbUser.authentication.logins.push(userObj.authenticationLogins.pop());
	      dbUser.contactInfo.location = (0, _extends3.default)({}, userObj.contactInfoLocation);
	      dbUser.shopping.cart = [].concat((0, _toConsumableArray3.default)(userObj.shoppingCart));
	      dbUser.socialProfileBlob[loginType] = userObj.socialProfileBlob[loginType];

	      dbUser.save({ validateBeforeSave: true }).then(resolve);
	    });
	  };

	  _userSchema2.default.statics.registerUser = function (userObj) {
	    return new _promise2.default(function (resolve, reject) {
	      var name = userObj.name,
	          pictures = userObj.pictures,
	          authentication = userObj.authentication,
	          authenticationLogins = userObj.authenticationLogins,
	          authenticationAuth0Identities = userObj.authenticationAuth0Identities,
	          contactInfo = userObj.contactInfo,
	          contactInfoLocation = userObj.contactInfoLocation,
	          contactInfoDevices = userObj.contactInfoDevices,
	          contactInfoSocialNetworks = userObj.contactInfoSocialNetworks,
	          shopping = userObj.shopping,
	          shoppingCart = userObj.shoppingCart,
	          permissions = userObj.permissions,
	          userStory = userObj.userStory,
	          socialProfileBlob = userObj.socialProfileBlob;


	      _bluebird.Promise.fromCallback(function (cb) {
	        return User.create({
	          name: name,
	          pictures: pictures,
	          authentication: (0, _extends3.default)({}, authentication, {
	            logins: [].concat((0, _toConsumableArray3.default)(authenticationLogins)),
	            auth0Identities: [].concat((0, _toConsumableArray3.default)(authenticationAuth0Identities))
	          }),
	          contactInfo: (0, _extends3.default)({}, contactInfo, {
	            location: (0, _extends3.default)({}, contactInfoLocation),
	            devices: [].concat((0, _toConsumableArray3.default)(contactInfoDevices)),
	            socialNetworks: [].concat((0, _toConsumableArray3.default)(contactInfoSocialNetworks))
	          }),
	          shopping: (0, _extends3.default)({}, shopping, {
	            cart: [].concat((0, _toConsumableArray3.default)(shoppingCart))
	          }),
	          permissions: permissions,
	          userStory: userStory,
	          socialProfileBlob: socialProfileBlob
	        }, cb);
	      }).then(function (newUser) {
	        console.log('\nNew User created!: ', newUser._id, '\nName: ', newUser.name.display, '\n');
	        resolve(newUser);
	      }).catch(reject);
	    });
	  };

	  _userSchema2.default.statics.addToMemberCart = function (_ref) {
	    var userId = _ref.userId,
	        qty = _ref.qty,
	        nicotineStrength = _ref.nicotineStrength,
	        product = _ref.product;
	    return new _promise2.default(function (resolve, reject) {
	      User.findById(userId).exec().then(function (dbUser) {
	        dbUser.shopping.cart.push({
	          qty: qty,
	          product: product,
	          nicotineStrength: nicotineStrength
	        });
	        return dbUser.save({ validateBeforeSave: true });
	      }).then(function (savedUser) {
	        console.log('Saved product to the User\'s Shopping Cart!');
	        resolve(savedUser);
	      }).catch(function (error) {
	        return reject({
	          problem: 'Could not save to the Users shopping cart.\n      args: {\n        userId: ' + userId + ',\n        qty: ' + qty + ',\n        nicotineStrength: ' + nicotineStrength + ',\n        product: ' + product + ',\n      }\n      Mongo Error: ' + error
	        });
	      });
	    });
	  };

	  _userSchema2.default.statics.deleteFromCart = function (_ref2) {
	    var userId = _ref2.userId,
	        productId = _ref2.productId;
	    return new _promise2.default(function (resolve, reject) {
	      User.findById(userId).exec().then(function (dbUser) {
	        dbUser.shopping.cart = dbUser.shopping.cart.filter(function (_ref3) {
	          var product = _ref3.product;
	          return String(product) !== String(productId);
	        });
	        return dbUser.save({ validateBeforeSave: true });
	      }).then(function (savedUser) {
	        console.log('\n        Deleted Product: ' + productId + ' from User: ' + savedUser._id + '.\n      ');
	        resolve(savedUser);
	      }).catch(function (error) {
	        return reject('\n      Could not Delete Product: ' + productId + ' from User: ' + userId + '.\n      Mongo Error = ' + error + '\n    ');
	      });
	    });
	  };

	  _userSchema2.default.statics.editToMemberCart = function (_ref4) {
	    var userId = _ref4.userId,
	        products = _ref4.products;
	    return new _promise2.default(function (resolve, reject) {
	      User.findById(userId).exec().then(function (dbUser) {
	        dbUser.shopping.cart = products;
	        return dbUser.save({ validateBeforeSave: true });
	      }).then(function (updatedUser) {
	        console.log('\n        Updated user shopping cart!\n      ');
	        resolve(updatedUser);
	      }).catch(function (error) {
	        return reject('\n      Could not Update User: ' + userId + '.\n\n      Mongo Error = ' + error + '\n    ');
	      });
	    });
	  };

	  var User = db.model('User', _userSchema2.default);
	  return User;
	};

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(10).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var userSchema = new Schema({
	  name: {
	    first: { type: String },
	    last: { type: String },
	    display: { type: String }
	  },
	  pictures: {
	    small: { type: String },
	    large: { type: String },
	    default: {
	      type: String,
	      default: 'https://s3-ap-northeast-1.amazonaws.com/nj2jp-react/default-user.png'
	    }
	  },
	  authentication: {
	    signedUp: { type: Date },
	    password: { type: String },
	    createdAt: { type: Date },
	    totalLogins: { type: Number },
	    lastLogin: [{
	      date: { type: Date, default: new Date() },
	      device: { type: String, default: 'computer' }
	    }],
	    ageVerified: { type: Boolean, default: false },
	    auth0Identities: [{
	      provider: { type: String },
	      user_id: { type: String },
	      connection: { type: String },
	      isSocial: { type: Boolean }
	    }]
	  },
	  contactInfo: {
	    email: { type: String },
	    phone: { type: String },
	    locale: { type: String },
	    timezone: { type: Number },
	    location: {
	      ipAddress: { type: String },
	      lat: { type: String },
	      long: { type: String },
	      country: { type: String }
	    },
	    devices: [{
	      hardware: { type: String },
	      os: { type: String }
	    }],
	    socialNetworks: [{
	      name: { type: String },
	      link: { type: String }
	    }]
	  },
	  shopping: {
	    cart: [{
	      qty: { type: Number },
	      nicotineStrength: { type: Number },
	      product: { type: ObjectId, ref: 'Product' }
	    }],
	    transactions: [{ type: ObjectId, ref: 'Transaction' }]
	  },
	  permissions: {
	    role: {
	      type: String,
	      enum: ['user', 'admin', 'devAdmin', 'wholeseller', 'distributor'],
	      required: true
	    }
	  },
	  userStory: {
	    age: { type: Number },
	    birthday: { type: Date },
	    bio: { type: String },
	    gender: { type: String }
	  },
	  marketHero: {
	    tags: [{
	      name: { type: String },
	      date: { type: Date }
	    }]
	  },
	  socialProfileBlob: {
	    line: { type: String },
	    facebook: { type: String },
	    google: { type: String },
	    twitter: { type: String },
	    linkedin: { type: String }
	  }
	});
	exports.default = userSchema;

/***/ }),
/* 19 */
/***/ (function(module, exports) {

	module.exports = require("dotenv");

/***/ }),
/* 20 */
/***/ (function(module, exports) {

	module.exports = require("request");

/***/ }),
/* 21 */
/***/ (function(module, exports) {

	module.exports = require("babel-polyfill");

/***/ })
/******/ ])));