(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _runGraphQL = __webpack_require__(1);

	var _runGraphQL2 = _interopRequireDefault(_runGraphQL);

	var _connection = __webpack_require__(8);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable global-require, import/first */
	if (!global._babelPolyfill) {
	  __webpack_require__(14);
	}

	module.exports.graphql = function (event, context, cb) {
	  (0, _runGraphQL2.default)(event, function (err, res) {
	    return (0, _connection.closeDB)(function () {
	      if (err) {
	        context.error(err);
	        return cb({ err: err });
	      }
	      console.log('context:', context, '\n'); // {}
	      context.succeed(res);
	      return cb(null, res);
	    });
	  });
	};

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(2);

	var _schema = __webpack_require__(3);

	var _schema2 = _interopRequireDefault(_schema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var runGraphQL = function runGraphQL(event, cb) {
	  var _event$body = event.body,
	      query = _event$body.query,
	      variables = _event$body.variables;

	  (0, _graphql.graphql)(_schema2.default, query, null, {}, variables).then(function (res) {
	    return cb(null, res);
	  }).catch(cb);
	};
	exports.default = runGraphQL;
	/*
	graphql(
	  schema: GraphQLSchema,
	  requestString: string,
	  rootValue?: ?any,
	  contextValue?: ?any,
	  variableValues?: ?{[key: string]: any},
	  operationName?: ?string
	): Promise<GraphQLResult>
	*/

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("graphql");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	var _graphql = __webpack_require__(2);

	var _productTypes = __webpack_require__(5);

	var _productTypes2 = _interopRequireDefault(_productTypes);

	var _userTypes = __webpack_require__(6);

	var _userTypes2 = _interopRequireDefault(_userTypes);

	var _product = __webpack_require__(7);

	var _product2 = _interopRequireDefault(_product);

	var _user = __webpack_require__(12);

	var _user2 = _interopRequireDefault(_user);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var query = new _graphql.GraphQLObjectType({
	  name: 'RootQueryType',
	  description: 'The primary query object type.',
	  fields: {
	    popularProducts: {
	      type: _productTypes2.default.rootType,
	      args: {
	        qty: {
	          type: _graphql.GraphQLInt,
	          description: 'The quantity of popular products to return.'
	        }
	      },
	      resolve: function resolve(_, args) {
	        return _bluebird2.default.fromCallback(function (cb) {
	          return _product2.default.getPopularProducts(args, cb);
	        });
	      }
	    }
	  }
	});

	var mutation = new _graphql.GraphQLObjectType({
	  name: 'RootMutationType',
	  fields: {
	    createUser: {
	      type: _userTypes2.default.rootType,
	      description: 'Create new user.',
	      args: _userTypes2.default.mutation.createUser.args,
	      resolve: function resolve(_, args) {
	        return _bluebird2.default.fromCallback(function (cb) {
	          return _user2.default.createUser(args, cb);
	        });
	      }
	    }
	  }
	});

	exports.default = new _graphql.GraphQLSchema({
	  query: query,
	  mutation: mutation
	});

/***/ }),
/* 4 */
/***/ (function(module, exports) {

	module.exports = require("bluebird");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(2);

	var ProductTypes = {
	  rootType: new _graphql.GraphQLObjectType({
	    name: 'Product',
	    description: 'A store product.',
	    fields: {
	      title: {
	        type: _graphql.GraphQLString,
	        description: 'Name of the product.'
	      },
	      flavor: {
	        type: _graphql.GraphQLString,
	        description: 'The flavor for the product (if applicable).'
	      },
	      price: {
	        type: _graphql.GraphQLString,
	        description: 'The price of the product.'
	      },
	      routeTag: {
	        type: _graphql.GraphQLString,
	        description: 'The name of the unique route for the product'
	      },
	      images: {
	        type: new _graphql.GraphQLList(new _graphql.GraphQLObjectType({
	          name: 'ProductImageType',
	          fields: function fields() {
	            return {
	              purpose: { type: _graphql.GraphQLString },
	              url: { type: _graphql.GraphQLString }
	            };
	          }
	        })),
	        description: 'Product images.'
	      }
	    }
	  })
	};
	exports.default = ProductTypes;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(2);

	var UserTypes = {
	  rootType: new _graphql.GraphQLObjectType({
	    name: 'RootUserType',
	    description: 'A User.',
	    fields: function fields() {
	      return {
	        name: {
	          type: new _graphql.GraphQLObjectType({
	            name: 'UserNameObject',
	            description: 'Users name object.',
	            fields: {
	              first: { type: _graphql.GraphQLString },
	              last: { type: _graphql.GraphQLString },
	              display: { type: _graphql.GraphQLString }
	            }
	          })
	        },
	        authentication: {
	          type: new _graphql.GraphQLObjectType({
	            name: 'UserAuthenticationObject',
	            description: 'Authentication information for user.',
	            fields: function fields() {
	              return {
	                lastLogin: { type: _graphql.GraphQLString },
	                signedUp: { type: _graphql.GraphQLString },
	                registered: { type: _graphql.GraphQLString },
	                password: { type: _graphql.GraphQLString },
	                avatar: { type: _graphql.GraphQLString }
	              };
	            }
	          })
	        },
	        contactInfo: {
	          type: new _graphql.GraphQLObjectType({
	            name: 'UserContanctInfoObject',
	            description: 'Geolocation information for user.',
	            fields: function fields() {
	              return {
	                email: { type: _graphql.GraphQLString },
	                phone: { type: _graphql.GraphQLString },
	                location: {
	                  type: new _graphql.GraphQLObjectType({
	                    name: 'UserGeolocationObject',
	                    fields: {
	                      ipAddress: { type: _graphql.GraphQLString },
	                      lat: { type: _graphql.GraphQLString },
	                      long: { type: _graphql.GraphQLString },
	                      country: { type: _graphql.GraphQLString }
	                    }
	                  })
	                }
	              };
	            }
	          })
	        },
	        permissions: {
	          type: new _graphql.GraphQLObjectType({
	            name: 'UserPermissionsObject',
	            description: 'Permissions granted for user.',
	            fields: function fields() {
	              return {
	                role: { type: _graphql.GraphQLString }
	              };
	            }
	          })
	        },
	        userStory: {
	          type: new _graphql.GraphQLObjectType({
	            name: 'UserStoryObject',
	            description: 'Bio information for user.',
	            fields: function fields() {
	              return {
	                age: { type: _graphql.GraphQLInt },
	                birthday: { type: _graphql.GraphQLString },
	                bio: { type: _graphql.GraphQLString }
	              };
	            }
	          })
	        }
	      };
	    }
	  }),
	  mutation: {
	    createUser: {
	      args: {
	        name: {
	          description: 'Object: Users name.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	            name: 'UserInputNameObject',
	            fields: function fields() {
	              return {
	                first: { type: _graphql.GraphQLString },
	                last: { type: _graphql.GraphQLString },
	                display: { type: _graphql.GraphQLString }
	              };
	            }
	          }))
	        },
	        authentication: {
	          description: 'Object: Auth info for user.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	            name: 'UserInputAuthenticationObject',
	            fields: function fields() {
	              return {
	                lastLogin: { type: _graphql.GraphQLString },
	                signedUp: { type: _graphql.GraphQLString },
	                registered: { type: _graphql.GraphQLString },
	                password: { type: _graphql.GraphQLString },
	                avatar: { type: _graphql.GraphQLString }
	              };
	            }
	          }))
	        },
	        contactInfo: {
	          description: 'Object: Contanct info for user.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	            name: 'UserInputContactInfoObject',
	            fields: function fields() {
	              return {
	                email: { type: _graphql.GraphQLString },
	                phone: { type: _graphql.GraphQLString },
	                location: {
	                  type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	                    name: 'UserInputGeolocationObject',
	                    description: 'Object: Geolocation information for user.',
	                    fields: function fields() {
	                      return {
	                        ipAddress: { type: _graphql.GraphQLString },
	                        lat: { type: _graphql.GraphQLString },
	                        long: { type: _graphql.GraphQLString },
	                        country: { type: _graphql.GraphQLString }
	                      };
	                    }
	                  }))
	                }
	              };
	            }
	          }))
	        },
	        permissions: {
	          description: 'Object: Permissions granted for user.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	            name: 'UserInputPermissionsObject',
	            fields: function fields() {
	              return {
	                role: { type: _graphql.GraphQLString }
	              };
	            }
	          }))
	        },
	        userStory: {
	          description: 'Object: Bio information for user.',
	          type: new _graphql.GraphQLNonNull(new _graphql.GraphQLInputObjectType({
	            name: 'UserInputStoryObject',
	            fields: function fields() {
	              return {
	                age: { type: _graphql.GraphQLInt },
	                birthday: { type: _graphql.GraphQLString },
	                bio: { type: _graphql.GraphQLString }
	              };
	            }
	          }))
	        }
	      }
	    }
	  }
	};
	exports.default = UserTypes;

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _connection = __webpack_require__(8);

	var _connection2 = _interopRequireDefault(_connection);

	var _productSchema = __webpack_require__(11);

	var _productSchema2 = _interopRequireDefault(_productSchema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define */
	_productSchema2.default.statics.getPopularProducts = function (_ref, cb) {
	  var qty = _ref.qty;

	  Product.find({}).then(function (dbProducts) {
	    return cb(null, dbProducts.slice(0, qty));
	  }).catch(function (err) {
	    return cb({
	      problem: 'Could not fetch the ' + qty + ' products you requested',
	      error: err
	    });
	  });
	};
	var Product = _connection2.default.model('Product', _productSchema2.default);
	exports.default = Product;

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.closeDB = undefined;

	var _mongoose = __webpack_require__(9);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	__webpack_require__(10).load({ silent: true });

	_mongoose2.default.Promise = _bluebird2.default;
	var MONGO_DB = process.env.AWS_MONGO_URI_DEV;
	var options = {
	  server: {
	    socketOptions: {
	      keepAlive: 30000,
	      connectTimeoutMS: 30000
	    }
	  }
	};
	var db = _mongoose2.default.createConnection(MONGO_DB, options, function (err) {
	  console.log(err || 'Mongo connected @ ' + MONGO_DB);
	});
	var closeDB = exports.closeDB = function closeDB(cb) {
	  return db.close(function () {
	    return cb();
	  });
	};
	exports.default = db;

/***/ }),
/* 9 */
/***/ (function(module, exports) {

	module.exports = require("mongoose");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

	module.exports = require("dotenv");

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(9).Schema;

	var ObjectId = Schema.Types.ObjectId;
	var productSchema = new Schema({
	  juice: {
	    mainTitle: {
	      type: String,
	      required: true
	    },
	    title: {
	      type: String,
	      required: true
	    },
	    flavor: {
	      type: String,
	      required: true
	    },
	    price: {
	      type: String,
	      required: true,
	      default: '30'
	    },
	    sku: {
	      type: String,
	      required: true
	    },
	    sizes: {
	      type: String,
	      enum: ['30', '60', '120'],
	      required: true
	    },
	    nicotine_strengths: {
	      type: Number,
	      enum: [2, 4, 6, 8, 12, 14, 16, 18],
	      required: true
	    },
	    images: [{
	      purpose: {
	        type: String,
	        required: true
	      },
	      url: {
	        type: String,
	        required: true
	      }
	    }],
	    routeTag: {
	      type: String,
	      required: true
	    },
	    vendor: { type: String },
	    dates: {
	      added_to_store: {
	        type: Date,
	        default: Date.now,
	        required: true
	      },
	      removed_from_store: {
	        type: Date,
	        default: Date.now,
	        required: true
	      }
	    },
	    quantities: {
	      available: { type: Number },
	      in_cart: { type: Number }
	    }
	  },
	  reviews: [{
	    reviews_id: { type: ObjectId, ref: 'Reviews' },
	    user_id: { type: ObjectId, ref: 'User' }
	  }],
	  distribution: {
	    restock_threshold: {
	      type: Number,
	      default: 500
	    },
	    restock_amount: {
	      type: Number,
	      default: 500
	    },
	    last_replenishment: [{
	      date: {
	        type: Date
	      },
	      amount: {
	        type: Number,
	        default: 500
	      }
	    }],
	    wholesale_price: { type: Number }
	  },
	  statistics: {
	    adds_to_cart: { type: Number },
	    completed_checkouts: { type: Number },
	    transactions: [{
	      transaction_id: { type: ObjectId, ref: 'Transaction' },
	      user_id: { type: ObjectId, ref: 'User' }
	    }]
	  }
	});
	exports.default = productSchema;

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _connection = __webpack_require__(8);

	var _connection2 = _interopRequireDefault(_connection);

	var _userSchema = __webpack_require__(13);

	var _userSchema2 = _interopRequireDefault(_userSchema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define */
	_userSchema2.default.statics.createUser = function (userInfo, cb) {
	  User.create(userInfo).then(function (newUser) {
	    return cb(null, newUser);
	  }).catch(function (error) {
	    return cb({ problem: 'Could not create User.', error: error });
	  });
	};
	var User = _connection2.default.model('User', _userSchema2.default);
	exports.default = User;

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(9).Schema;

	var ObjectId = Schema.Types.ObjectId;
	var userSchema = new Schema({
	  name: {
	    first: { type: String },
	    last: { type: String },
	    display: { type: String }
	  },
	  authentication: {
	    lastLogin: { type: Date },
	    signedUp: { type: Date },
	    registered: { type: Date },
	    password: { type: String },
	    avatar: {
	      type: String,
	      default: 'https://s3-ap-northeast-1.amazonaws.com/nj2jp-react/default-user.png'
	    }
	  },
	  contactInfo: {
	    email: { type: String },
	    phone: { type: Number },
	    location: {
	      ipAddress: { type: String },
	      lat: { type: String },
	      long: { type: String },
	      country: { type: String }
	    }
	  },
	  transactions: {
	    orders: [{
	      type: { type: ObjectId, ref: 'Transaction' }
	    }]
	  },
	  permissions: {
	    role: {
	      type: String,
	      enum: ['user', 'admin', 'devAdmin', 'wholeseller', 'distributor'],
	      required: true
	    }
	  },
	  userStory: {
	    age: { type: Number },
	    birthday: { type: Date },
	    bio: { type: String }
	  },
	  socialProfileBlob: {}
	});
	exports.default = userSchema;

/***/ }),
/* 14 */
/***/ (function(module, exports) {

	module.exports = require("babel-polyfill");

/***/ })
/******/ ])));