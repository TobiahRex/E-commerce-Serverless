(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _graphql = __webpack_require__(1);

	var _graphql2 = _interopRequireDefault(_graphql);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	module.exports.graphql = function (event, context, cb) {
	  (0, _graphql2.default)(event, function (err, res) {
	    if (err) return cb(err);
	    return cb(null, res);
	  });
	};

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(2);

	var _schema = __webpack_require__(3);

	var _schema2 = _interopRequireDefault(_schema);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var runGraphQL = function runGraphQL(event, cb) {
	  var _event$body = event.body,
	      query = _event$body.query,
	      variables = _event$body.variables;

	  (0, _graphql.graphql)(_schema2.default, query, null, {}, variables).then(function (res) {
	    return cb(null, res);
	  }).catch(cb);
	};
	exports.default = runGraphQL;
	/*
	graphql(
	  schema: GraphQLSchema,
	  requestString: string,
	  rootValue?: ?any,
	  contextValue?: ?any,
	  variableValues?: ?{[key: string]: any},
	  operationName?: ?string
	): Promise<GraphQLResult>
	*/

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("graphql");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	var _graphql = __webpack_require__(2);

	var _imports = __webpack_require__(5);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var Query = new _graphql.GraphQLObjectType({
	  name: 'RootQueryType',
	  description: 'The root query.',
	  fields: {
	    // popularJuices: {
	    //   type: new GraphQLList(popularJuicesType),
	    //   description: 'The 6 most popular juices.',
	    //   resolve: Product.getPopularJuices,
	    // },
	  }
	});
	// import { GraphQLError } from 'graphql/error';


	var Mutation = new _graphql.GraphQLObjectType({
	  name: 'RootMutationType',
	  desciption: 'The root mutation type.',
	  fields: {
	    createUser: {
	      type: _imports.UserTypes.rootType,
	      description: 'Create new user.',
	      args: {
	        name: _imports.UserTypes.createUserInput.name,
	        authentication: _imports.UserTypes.createUserInput.authentication,
	        contactInfo: _imports.UserTypes.createUserInput.contactInfo,
	        permissions: _imports.UserTypes.createUserInput.permissions,
	        userStory: _imports.UserTypes.createUserInput.userStory,
	        socialBlob: {
	          type: new _graphql.GraphQLNonNull(_graphql.GraphQLString)
	        }
	      },
	      resolve: function resolve(_, args) {
	        return _bluebird2.default.fromCallback(function (cb) {
	          return _imports.UserModel.createUser(args, cb);
	        });
	      }
	    }
	  }
	});

	var Schema = new _graphql.GraphQLSchema({
	  query: Query,
	  mutation: Mutation
	});

	exports.default = Schema;

/***/ }),
/* 4 */
/***/ (function(module, exports) {

	module.exports = require("bluebird");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _product = __webpack_require__(6);

	Object.defineProperty(exports, 'ProductModel', {
	  enumerable: true,
	  get: function get() {
	    return _product.Product;
	  }
	});

	var _transaction = __webpack_require__(8);

	Object.defineProperty(exports, 'TransactionModel', {
	  enumerable: true,
	  get: function get() {
	    return _transaction.Transaction;
	  }
	});

	var _user = __webpack_require__(9);

	Object.defineProperty(exports, 'UserModel', {
	  enumerable: true,
	  get: function get() {
	    return _user.User;
	  }
	});

	var _userTypes = __webpack_require__(10);

	Object.defineProperty(exports, 'UserTypes', {
	  enumerable: true,
	  get: function get() {
	    return _userTypes.UserTypes;
	  }
	});

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _mongoose = __webpack_require__(7);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define */
	_mongoose2.default.Promise = _bluebird2.default;
	var ObjectId = _mongoose2.default.Schema.Types.ObjectId;
	var Products = _mongoose2.default.model('Products', new _mongoose2.default.Schema({
	  juice: {
	    mainTitle: {
	      type: String,
	      required: true
	    },
	    title: {
	      type: String,
	      required: true
	    },
	    flavor: {
	      type: String,
	      required: true
	    },
	    price: {
	      type: String,
	      required: true,
	      default: '30'
	    },
	    sku: {
	      type: String,
	      required: true
	    },
	    sizes: {
	      type: String,
	      enum: ['30', '60', '120'],
	      required: true
	    },
	    nicotine_strengths: {
	      type: Number,
	      enum: [2, 4, 6, 8, 12, 14, 16, 18],
	      required: true
	    },
	    images: [{
	      purpose: {
	        type: String,
	        required: true
	      },
	      url: {
	        type: String,
	        required: true
	      }
	    }],
	    routeTag: {
	      type: String,
	      required: true
	    },
	    vendor: { type: String },
	    dates: {
	      added_to_store: {
	        type: Date,
	        default: Date.now,
	        required: true
	      },
	      removed_from_store: {
	        type: Date,
	        default: Date.now,
	        required: true
	      }
	    },
	    quantities: {
	      available: { type: Number },
	      in_cart: { type: Number }
	    }
	  },
	  reviews: [{
	    reviews_id: { type: ObjectId, ref: 'Reviews' },
	    user_id: { type: ObjectId, ref: 'User' }
	  }],
	  distribution: {
	    restock_threshold: {
	      type: Number,
	      default: 500
	    },
	    restock_amount: {
	      type: Number,
	      default: 500
	    },
	    last_replenishment: [{
	      date: {
	        type: Date
	      },
	      amount: {
	        type: Number,
	        default: 500
	      }
	    }],
	    wholesale_price: { type: Number }
	  },
	  statistics: {
	    adds_to_cart: { type: Number },
	    completed_checkouts: { type: Number },
	    transactions: [{
	      transaction_id: { type: ObjectId, ref: 'Transaction' },
	      user_id: { type: ObjectId, ref: 'User' }
	    }]
	  }
	}));
	exports.default = Products;

/***/ }),
/* 7 */
/***/ (function(module, exports) {

	module.exports = require("mongoose");

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _mongoose = __webpack_require__(7);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define */
	_mongoose2.default.Promise = _bluebird2.default;
	var ObjectId = _mongoose2.default.Schema.Types.ObjectId;
	var Transaction = _mongoose2.default.model('Transaction', new _mongoose2.default.Schema({
	  date: {
	    type: Date,
	    default: Date.now,
	    required: true
	  },
	  user: { type: ObjectId, ref: 'User' },
	  products: [{
	    id: { type: ObjectId, ref: 'Product' }
	  }],
	  subtotal: { type: String, required: true },
	  tax: { type: String, required: true },
	  grandTotal: { type: String, required: true },
	  distribution: {
	    address: {
	      boxid: { type: String, required: true },
	      shipdate: { type: Date, required: true },
	      kana: { type: String, required: true },
	      productNameKana: { type: String, required: true },
	      postal: { type: Number, required: true },
	      jpaddress1: { type: String, required: true },
	      jpaddress2: { type: String, required: true },
	      contel: { type: Number, required: true },
	      kbn: { type: Number, required: true },
	      wgt: { type: Number, required: true }
	    },
	    item: {
	      itemcd: { type: Number, required: true },
	      itemname: { type: String, required: true },
	      usage: { type: Number, default: 0 },
	      origin: { type: String },
	      piece: { type: Number, required: true, default: 1 },
	      unitprice: { type: Number, required: true }
	    }
	  }
	}));

	exports.default = Transaction;

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; /* eslint-disable no-use-before-define */


	var _mongoose = __webpack_require__(7);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _bluebird = __webpack_require__(4);

	var _bluebird2 = _interopRequireDefault(_bluebird);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	_mongoose2.default.Promise = _bluebird2.default;
	var ObjectId = _mongoose2.default.schema.Types.ObjectId;
	var userSchema = new _mongoose2.default.Schema({
	  name: {
	    first: { type: String },
	    last: { type: String },
	    display: { type: String }
	  },
	  authentication: {
	    lastLogin: { type: Date },
	    signedUp: { type: Date },
	    registered: { type: Date },
	    password: { type: String },
	    avatar: {
	      type: String,
	      default: 'https://s3-ap-northeast-1.amazonaws.com/nj2jp-react/default-user.png'
	    }
	  },
	  contactInfo: {
	    email: { type: String },
	    phone: { type: Number },
	    location: {
	      ipAddress: { type: String },
	      lat: { type: String },
	      long: { type: String },
	      country: { type: String }
	    }
	  },
	  transactions: {
	    orders: [{
	      type: { type: ObjectId, ref: 'Transaction' }
	    }]
	  },
	  permissions: {
	    role: {
	      type: String,
	      enum: ['user', 'admin', 'devAdmin', 'wholeseller', 'distributor'],
	      required: true
	    }
	  },
	  userStory: {
	    age: { type: Number },
	    birthday: { type: Date },
	    bio: { type: String }
	  },
	  socialProfileBlob: {}
	});

	userSchema.statics.createUser = function (args, cb) {
	  User.create(_extends({}, args)).then(function (dbUser) {
	    return cb(null, dbUser);
	  }).catch(cb);
	};

	var User = _mongoose2.default.model('User', userSchema);
	exports.default = User;

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _graphql = __webpack_require__(2);

	var UserTypes = {
	  rootType: {
	    name: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputNameObject',
	      description: 'Users name object.',
	      fields: function fields() {
	        return {
	          first: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          last: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          display: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) }
	        };
	      }
	    }),
	    authentication: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputAuthenticationObject',
	      description: 'Authentication information for user.',
	      fields: function fields() {
	        return {
	          lastLogin: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          signedUp: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          registered: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          password: { type: _graphql.GraphQLString },
	          avatar: { type: _graphql.GraphQLString }
	        };
	      }
	    }),
	    contactInfo: new _graphql.GraphQLInputObjectType({
	      email: { type: _graphql.GraphQLString },
	      phone: { type: _graphql.GraphQLString },
	      location: new _graphql.GraphQLInputObjectType({
	        name: 'UserInputGeolocationObject',
	        description: 'Geolocation information for user.',
	        fields: function fields() {
	          return {
	            ipAddress: { type: _graphql.GraphQLString },
	            lat: { type: _graphql.GraphQLString },
	            long: { type: _graphql.GraphQLString },
	            country: { type: _graphql.GraphQLString }
	          };
	        }
	      })
	    }),
	    permissions: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputPermissionsObject',
	      description: 'Permissions granted for user.',
	      fields: function fields() {
	        return {
	          role: { type: _graphql.GraphQLString }
	        };
	      }
	    }),
	    userStory: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputStoryObject',
	      description: 'Bio information for user.',
	      fields: function fields() {
	        return {
	          age: { type: _graphql.GraphQLInt },
	          birthday: { type: _graphql.GraphQLString },
	          bio: { type: _graphql.GraphQLString }
	        };
	      }
	    })
	  },
	  createUserInput: {
	    name: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputNameObject',
	      description: 'Users name object.',
	      fields: function fields() {
	        return {
	          first: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          last: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          display: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) }
	        };
	      }
	    }),
	    authentication: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputAuthenticationObject',
	      description: 'Authentication information for user.',
	      fields: function fields() {
	        return {
	          lastLogin: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          signedUp: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          registered: { type: (0, _graphql.GraphQLNonNull)(_graphql.GraphQLString) },
	          password: { type: _graphql.GraphQLString },
	          avatar: { type: _graphql.GraphQLString }
	        };
	      }
	    }),
	    contactInfo: new _graphql.GraphQLInputObjectType({
	      email: { type: _graphql.GraphQLString },
	      phone: { type: _graphql.GraphQLString },
	      location: new _graphql.GraphQLInputObjectType({
	        name: 'UserInputGeolocationObject',
	        description: 'Geolocation information for user.',
	        fields: function fields() {
	          return {
	            ipAddress: { type: _graphql.GraphQLString },
	            lat: { type: _graphql.GraphQLString },
	            long: { type: _graphql.GraphQLString },
	            country: { type: _graphql.GraphQLString }
	          };
	        }
	      })
	    }),
	    permissions: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputPermissionsObject',
	      description: 'Permissions granted for user.',
	      fields: function fields() {
	        return {
	          role: { type: _graphql.GraphQLString }
	        };
	      }
	    }),
	    userStory: new _graphql.GraphQLInputObjectType({
	      name: 'UserInputStoryObject',
	      description: 'Bio information for user.',
	      fields: function fields() {
	        return {
	          age: { type: _graphql.GraphQLInt },
	          birthday: { type: _graphql.GraphQLString },
	          bio: { type: _graphql.GraphQLString }
	        };
	      }
	    })
	  }
	};
	exports.default = UserTypes;

/***/ })
/******/ ])));